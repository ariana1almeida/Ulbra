#include<stdio.h>

int main (){
	int num1, num2;
	printf("Digite o primeiro numero:");
	scanf("%d%*c", &num1);
	
	printf("Digite o segundo numero:");
	scanf("%d%*c", &num2);
	
	if(num1> num2){
		printf("O maior numero e: %d\n",num1);
	} else if(num2 > num1){
		printf("O maior numero e: %d\n", num2);
	} else if (num1==num2){
		printf ("Os numeros sao iguais");
	}
	
	return 0;
}
