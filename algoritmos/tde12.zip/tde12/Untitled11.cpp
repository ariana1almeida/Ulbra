#include <stdio.h>

int main(){
	int tamanho=10;
	int matricula;
	char nome[10];
	float nota, media, soma;
	int i,j;
	
	for(i=0;i<tamanho;i++){
		printf("Digite a matricula\n");
		scanf("%d%*c", &matricula);
		printf("Digite o nome\n");
		scanf("%s%*c", &nome);
		
		soma=0;
		for(j=0;j<3;j++){
			printf("Digite a nota %d\n");
		}
	}
}
